/* =========================================================
   Technosankalp Solutions - board3d.js
   Interactive 3D Microcontroller Board Viewer (Three.js)
   ========================================================= */

let scene, camera, renderer, currentBoardMesh;
let isDragging = false;
let previousMousePosition = { x: 0, y: 0 };
let autoRotate = true;

const BOARD_SPECS = {
  esp32: {
    title: "ESP32-WROOM-32 DevKit V1",
    chip: "Xtensa® Dual-Core 32-bit LX6 (240 MHz)",
    wireless: "Wi-Fi 802.11 b/g/n + Bluetooth 4.2 BR/EDR & BLE",
    memory: "520 KB SRAM / 4 MB Flash",
    pins: "30 GPIOs (ADC, DAC, PWM, SPI, I2C, UART, Capacitive Touch)",
    voltage: "3.3V Logic / 5V USB Input",
    color: 0x111625
  },
  uno: {
    title: "Arduino Uno Rev3",
    chip: "ATmega328P 8-bit AVR Microcontroller (16 MHz)",
    wireless: "Requires external shield (NFR24L01 / HC-05)",
    memory: "2 KB SRAM / 32 KB Flash / 1 KB EEPROM",
    pins: "14 Digital I/O (6 PWM) + 6 Analog Inputs (10-bit ADC)",
    voltage: "5V Operating Voltage / 7-12V Input",
    color: 0x0e5c94
  },
  pico: {
    title: "Raspberry Pi Pico (RP2040)",
    chip: "Dual-Core ARM Cortex-M0+ (133 MHz)",
    wireless: "RP2040 (Optionally WiFi 802.11n on Pico W)",
    memory: "264 KB SRAM / 2 MB QSPI Flash",
    pins: "26 Multi-function GPIO (3 Analog inputs, 2 SPI, 2 I2C, 2 UART)",
    voltage: "3.3V Operating / 1.8-5.5V DC USB Input",
    color: 0x0f6336
  },
  nodemcu: {
    title: "ESP8266 NodeMCU v2",
    chip: "Tensilica Xtensa® Single-Core L106 (80 MHz)",
    wireless: "Wi-Fi 802.11 b/g/n (2.4 GHz)",
    memory: "160 KB SRAM / 4 MB Flash",
    pins: "10 GPIOs (1 Analog Input 1.0V max, PWM, I2C, SPI)",
    voltage: "3.3V Operating / 5V USB Input",
    color: 0x181e2b
  }
};

function init3DBoardViewer(containerId) {
  const container = document.getElementById(containerId);
  if (!container || typeof THREE === 'undefined') return;

  const width = container.clientWidth || 600;
  const height = container.clientHeight || 360;

  // Scene
  scene = new THREE.Scene();

  // Camera
  camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 1000);
  camera.position.set(0, 4.5, 6.5);
  camera.lookAt(0, 0, 0);

  // Renderer
  renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
  renderer.setSize(width, height);
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;

  container.appendChild(renderer.domElement);

  // Lighting
  const ambientLight = new THREE.AmbientLight(0xffffff, 0.75);
  scene.add(ambientLight);

  const dirLight1 = new THREE.DirectionalLight(0xffffff, 1.2);
  dirLight1.position.set(5, 10, 7);
  dirLight1.castShadow = true;
  scene.add(dirLight1);

  const dirLight2 = new THREE.DirectionalLight(0x6366f1, 0.8);
  dirLight2.position.set(-5, -5, -5);
  scene.add(dirLight2);

  const pointLight = new THREE.PointLight(0x22d3ee, 1, 10);
  pointLight.position.set(0, 2, 2);
  scene.add(pointLight);

  // Render initial board (ESP32)
  load3DBoardMesh('esp32');

  // Mouse Interaction (Orbit Controls)
  const dom = renderer.domElement;
  dom.addEventListener('mousedown', (e) => {
    isDragging = true;
    previousMousePosition = { x: e.clientX, y: e.clientY };
  });

  dom.addEventListener('mousemove', (e) => {
    if (!isDragging || !currentBoardMesh) return;
    const deltaX = e.clientX - previousMousePosition.x;
    const deltaY = e.clientY - previousMousePosition.y;

    currentBoardMesh.rotation.y += deltaX * 0.01;
    currentBoardMesh.rotation.x += deltaY * 0.01;

    previousMousePosition = { x: e.clientX, y: e.clientY };
  });

  window.addEventListener('mouseup', () => { isDragging = false; });

  dom.addEventListener('wheel', (e) => {
    e.preventDefault();
    camera.position.z += e.deltaY * 0.005;
    camera.position.z = Math.max(3, Math.min(10, camera.position.z));
  });

  // Animation Loop
  function animate() {
    requestAnimationFrame(animate);
    if (currentBoardMesh && autoRotate && !isDragging) {
      currentBoardMesh.rotation.y += 0.006;
    }
    renderer.render(scene, camera);
  }
  animate();

  // Resize handler
  window.addEventListener('resize', () => {
    if (!container) return;
    const w = container.clientWidth;
    const h = container.clientHeight;
    camera.aspect = w / h;
    camera.updateProjectionMatrix();
    renderer.setSize(w, h);
  });
}

function load3DBoardMesh(type) {
  if (currentBoardMesh) {
    scene.remove(currentBoardMesh);
  }

  const spec = BOARD_SPECS[type] || BOARD_SPECS.esp32;
  currentBoardMesh = new THREE.Group();

  // 1. PCB Base Plate
  let pcbWidth = 4.2;
  let pcbLength = 2.4;
  if (type === 'uno') { pcbWidth = 4.8; pcbLength = 3.6; }
  else if (type === 'pico') { pcbWidth = 3.8; pcbLength = 1.8; }

  const pcbGeo = new THREE.BoxGeometry(pcbWidth, 0.15, pcbLength);
  const pcbMat = new THREE.MeshStandardMaterial({
    color: spec.color,
    roughness: 0.3,
    metalness: 0.1
  });
  const pcbMesh = new THREE.Mesh(pcbGeo, pcbMat);
  pcbMesh.receiveShadow = true;
  pcbMesh.castShadow = true;
  currentBoardMesh.add(pcbMesh);

  // 2. Main Chip / Metallic Shield
  if (type === 'esp32' || type === 'nodemcu') {
    // Metal RF Shield Box (ESP-WROOM-32)
    const shieldGeo = new THREE.BoxGeometry(1.6, 0.25, 1.4);
    const shieldMat = new THREE.MeshStandardMaterial({ color: 0xd1d5db, metalness: 0.95, roughness: 0.15 });
    const shield = new THREE.Mesh(shieldGeo, shieldMat);
    shield.position.set(-0.6, 0.2, 0);
    currentBoardMesh.add(shield);

    // PCB Trace Antenna (Gold/Black)
    const antGeo = new THREE.BoxGeometry(0.8, 0.1, 1.3);
    const antMat = new THREE.MeshStandardMaterial({ color: 0xb45309, metalness: 0.6 });
    const antenna = new THREE.Mesh(antGeo, antMat);
    antenna.position.set(1.4, 0.1, 0);
    currentBoardMesh.add(antenna);
  } else if (type === 'uno') {
    // ATmega328P DIP Chip
    const dipGeo = new THREE.BoxGeometry(2.2, 0.3, 0.7);
    const dipMat = new THREE.MeshStandardMaterial({ color: 0x1f2937, roughness: 0.8 });
    const dip = new THREE.Mesh(dipGeo, dipMat);
    dip.position.set(0.2, 0.22, 0.4);
    currentBoardMesh.add(dip);

    // USB Type-B Connector
    const usbGeo = new THREE.BoxGeometry(1.0, 0.8, 1.0);
    const usbMat = new THREE.MeshStandardMaterial({ color: 0x9ca3af, metalness: 0.9, roughness: 0.2 });
    const usb = new THREE.Mesh(usbGeo, usbMat);
    usb.position.set(-1.8, 0.45, -1.1);
    currentBoardMesh.add(usb);

    // Barrel DC Jack
    const dcGeo = new THREE.BoxGeometry(1.2, 0.8, 0.9);
    const dcMat = new THREE.MeshStandardMaterial({ color: 0x111827, roughness: 0.4 });
    const dc = new THREE.Mesh(dcGeo, dcMat);
    dc.position.set(-1.7, 0.45, 1.1);
    currentBoardMesh.add(dc);
  } else if (type === 'pico') {
    // RP2040 QFN Chip
    const qfnGeo = new THREE.BoxGeometry(0.8, 0.15, 0.8);
    const qfnMat = new THREE.MeshStandardMaterial({ color: 0x111827, roughness: 0.5 });
    const qfn = new THREE.Mesh(qfnGeo, qfnMat);
    qfn.position.set(0, 0.15, 0);
    currentBoardMesh.add(qfn);
  }

  // 3. Micro-USB Port
  if (type !== 'uno') {
    const microUsbGeo = new THREE.BoxGeometry(0.6, 0.25, 0.5);
    const microUsbMat = new THREE.MeshStandardMaterial({ color: 0x9ca3af, metalness: 0.9 });
    const microUsb = new THREE.Mesh(microUsbGeo, microUsbMat);
    microUsb.position.set(-pcbWidth / 2 + 0.3, 0.2, 0);
    currentBoardMesh.add(microUsb);
  }

  // 4. Male / Female Header Pins
  const pinMat = new THREE.MeshStandardMaterial({ color: 0xd97706, metalness: 0.85, roughness: 0.2 });
  const pinRows = [-pcbLength / 2 + 0.2, pcbLength / 2 - 0.2];
  
  pinRows.forEach(zPos => {
    const pinCount = Math.floor(pcbWidth * 3.5);
    for (let i = 0; i < pinCount; i++) {
      const pinGeo = new THREE.BoxGeometry(0.08, 0.5, 0.08);
      const pin = new THREE.Mesh(pinGeo, pinMat);
      const xPos = -pcbWidth / 2 + 0.3 + (i * 0.25);
      pin.position.set(xPos, -0.2, zPos);
      currentBoardMesh.add(pin);
    }
  });

  scene.add(currentBoardMesh);
  updateBoardInfoSpecs(spec);
}

function updateBoardInfoSpecs(spec) {
  const titleEl = document.getElementById('board3d-title');
  const chipEl = document.getElementById('board3d-chip');
  const wirelessEl = document.getElementById('board3d-wireless');
  const memoryEl = document.getElementById('board3d-memory');
  const pinsEl = document.getElementById('board3d-pins');
  const voltageEl = document.getElementById('board3d-voltage');

  if (titleEl) titleEl.textContent = spec.title;
  if (chipEl) chipEl.textContent = spec.chip;
  if (wirelessEl) wirelessEl.textContent = spec.wireless;
  if (memoryEl) memoryEl.textContent = spec.memory;
  if (pinsEl) pinsEl.textContent = spec.pins;
  if (voltageEl) voltageEl.textContent = spec.voltage;
}

function switch3DBoard(type) {
  document.querySelectorAll('.board-3d-btn').forEach(btn => btn.classList.remove('active'));
  const activeBtn = document.getElementById('btn-3d-' + type);
  if (activeBtn) activeBtn.classList.add('active');

  load3DBoardMesh(type);
}
