/* =========================================================
   Technosankalp Solutions - blockly_arduino.js
   Block-Based CodeBlocks Engine (Dual Dark/Light Themes)
   ========================================================= */

var blocklyWorkspace = null;
var currentEditMode = 'text';
var codeblocksDarkTheme = null;
var codeblocksLightTheme = null;

// Register Custom Vibrant Arduino Blocks with Optimized Contrast
function initBlocklyArduino() {
  if (typeof Blockly === 'undefined') return;

  // 1. Program Setup & Loop
  Blockly.Blocks['arduino_program'] = {
    init: function() {
      this.appendDummyInput().appendField("⚡ Arduino / ESP32 Program");
      this.appendStatementInput("SETUP").appendField("on setup ()");
      this.appendStatementInput("LOOP").appendField("every loop ()");
      this.setColour("#6366f1");
      this.setDeletable(false);
      this.setTooltip("Main Arduino execution lifecycle");
    }
  };

  // 2. Delay
  Blockly.Blocks['arduino_delay'] = {
    init: function() {
      this.appendDummyInput()
          .appendField("delay")
          .appendField(new Blockly.FieldNumber(1000, 0), "MS")
          .appendField("ms");
      this.setPreviousStatement(true, null);
      this.setNextStatement(true, null);
      this.setColour("#6366f1");
    }
  };

  // 3. Serial Print
  Blockly.Blocks['arduino_serial_print'] = {
    init: function() {
      this.appendValueInput("TEXT")
          .setCheck(null)
          .appendField("Serial print line");
      this.setPreviousStatement(true, null);
      this.setNextStatement(true, null);
      this.setColour("#6366f1");
    }
  };

  // 4. Digital Write
  Blockly.Blocks['arduino_digital_write'] = {
    init: function() {
      this.appendDummyInput()
          .appendField("set digital pin")
          .appendField(new Blockly.FieldDropdown([
            ["LED_BUILTIN", "LED_BUILTIN"],
            ["Pin 2", "2"],
            ["Pin 4", "4"],
            ["Pin 5", "5"],
            ["Pin 13", "13"],
            ["Pin 18", "18"],
            ["Pin 21", "21"],
            ["Pin 22", "22"]
          ]), "PIN")
          .appendField("to")
          .appendField(new Blockly.FieldDropdown([["HIGH ⚡", "HIGH"], ["LOW ◯", "LOW"]]), "STAT");
      this.setPreviousStatement(true, null);
      this.setNextStatement(true, null);
      this.setColour("#0284c7");
    }
  };

  // 5. Digital Read
  Blockly.Blocks['arduino_digital_read'] = {
    init: function() {
      this.appendDummyInput()
          .appendField("read digital pin")
          .appendField(new Blockly.FieldDropdown([
            ["Pin 2", "2"],
            ["Pin 4", "4"],
            ["Pin 5", "5"],
            ["Pin 17", "17"]
          ]), "PIN");
      this.setOutput(true, "Boolean");
      this.setColour("#0284c7");
    }
  };

  // 6. Analog Read
  Blockly.Blocks['arduino_analog_read'] = {
    init: function() {
      this.appendDummyInput()
          .appendField("read analog pin")
          .appendField(new Blockly.FieldDropdown([
            ["A0", "A0"],
            ["A1", "A1"],
            ["GPIO 34 (ADC1)", "34"],
            ["GPIO 36 (VP)", "36"]
          ]), "PIN");
      this.setOutput(true, "Number");
      this.setColour("#0284c7");
    }
  };

  // 7. PWM Write
  Blockly.Blocks['arduino_pwm_write'] = {
    init: function() {
      this.appendDummyInput()
          .appendField("set PWM pin")
          .appendField(new Blockly.FieldNumber(9, 0, 39), "PIN")
          .appendField("brightness (0-255)")
          .appendField(new Blockly.FieldNumber(128, 0, 255), "VAL");
      this.setPreviousStatement(true, null);
      this.setNextStatement(true, null);
      this.setColour("#0284c7");
    }
  };

  // 8. Servo Motor
  Blockly.Blocks['arduino_servo'] = {
    init: function() {
      this.appendDummyInput()
          .appendField("rotate Servo pin")
          .appendField(new Blockly.FieldNumber(18, 0, 39), "PIN")
          .appendField("to angle")
          .appendField(new Blockly.FieldNumber(90, 0, 180), "ANGLE")
          .appendField("°");
      this.setPreviousStatement(true, null);
      this.setNextStatement(true, null);
      this.setColour("#d97706");
    }
  };

  // 9. OLED Print
  Blockly.Blocks['arduino_oled_print'] = {
    init: function() {
      this.appendValueInput("TEXT")
          .setCheck(null)
          .appendField("SSD1306 OLED print text");
      this.setPreviousStatement(true, null);
      this.setNextStatement(true, null);
      this.setColour("#d97706");
    }
  };

  // 10. Active Buzzer Tone
  Blockly.Blocks['arduino_buzzer'] = {
    init: function() {
      this.appendDummyInput()
          .appendField("play buzzer pin")
          .appendField(new Blockly.FieldNumber(15, 0, 39), "PIN")
          .appendField("duration")
          .appendField(new Blockly.FieldNumber(200, 10, 5000), "MS")
          .appendField("ms");
      this.setPreviousStatement(true, null);
      this.setNextStatement(true, null);
      this.setColour("#d97706");
    }
  };

  // 11. DHT22 Sensor
  Blockly.Blocks['arduino_dht'] = {
    init: function() {
      this.appendDummyInput()
          .appendField("read DHT22")
          .appendField(new Blockly.FieldDropdown([["Temperature (°C)", "TEMP"], ["Humidity (%)", "HUM"]]), "TYPE")
          .appendField("pin")
          .appendField(new Blockly.FieldNumber(4, 0, 39), "PIN");
      this.setOutput(true, "Number");
      this.setColour("#059669");
    }
  };

  // 12. Ultrasonic HC-SR04
  Blockly.Blocks['arduino_ultrasonic'] = {
    init: function() {
      this.appendDummyInput()
          .appendField("read ultrasonic distance cm (Trig")
          .appendField(new Blockly.FieldNumber(2, 0, 39), "TRIG")
          .appendField(", Echo")
          .appendField(new Blockly.FieldNumber(3, 0, 39), "ECHO")
          .appendField(")");
      this.setOutput(true, "Number");
      this.setColour("#059669");
    }
  };

  // 13. Text Literal
  Blockly.Blocks['text_literal'] = {
    init: function() {
      this.appendDummyInput()
          .appendField('"')
          .appendField(new Blockly.FieldTextInput("Hello Technosankalp!"), "TEXT")
          .appendField('"');
      this.setOutput(true, "String");
      this.setColour("#0d9488");
    }
  };
}

// Instantiate Blockly Workspace with Custom Themes
function setupBlocklyWorkspace() {
  if (blocklyWorkspace || typeof Blockly === 'undefined') return;

  initBlocklyArduino();

  // Define Dark Theme
  if (Blockly.Theme && Blockly.Theme.defineTheme) {
    codeblocksDarkTheme = Blockly.Theme.defineTheme('codeblocks_dark', {
      base: Blockly.Themes.Classic || null,
      componentStyles: {
        workspaceBackgroundColour: '#0b0d17',
        toolboxBackgroundColour: '#10131f',
        toolboxForegroundColour: '#f8fafc',
        flyoutBackgroundColour: '#141828',
        flyoutForegroundColour: '#f8fafc',
        flyoutOpacity: 0.95,
        scrollbarColour: '#252a45',
        scrollbarOpacity: 0.8,
        insertionMarkerColour: '#6366f1',
        insertionMarkerOpacity: 0.5
      },
      fontStyle: {
        family: "'Inter', sans-serif",
        weight: 'bold',
        size: 12
      }
    });

    codeblocksLightTheme = Blockly.Theme.defineTheme('codeblocks_light', {
      base: Blockly.Themes.Classic || null,
      componentStyles: {
        workspaceBackgroundColour: '#f8fafc',
        toolboxBackgroundColour: '#ffffff',
        toolboxForegroundColour: '#0f172a',
        flyoutBackgroundColour: '#f1f5f9',
        flyoutForegroundColour: '#0f172a',
        flyoutOpacity: 0.95,
        scrollbarColour: '#cbd5e1',
        scrollbarOpacity: 0.8,
        insertionMarkerColour: '#6366f1',
        insertionMarkerOpacity: 0.5
      },
      fontStyle: {
        family: "'Inter', sans-serif",
        weight: 'bold',
        size: 12
      }
    });
  }

  var toolboxXml = `
    <xml id="toolbox" style="display: none">
      <category name="Setup & Loop" colour="#6366f1">
        <block type="arduino_program"></block>
        <block type="arduino_delay"></block>
        <block type="arduino_serial_print">
          <value name="TEXT">
            <block type="text_literal"></block>
          </value>
        </block>
      </category>
      <category name="Pins & GPIO" colour="#0284c7">
        <block type="arduino_digital_write"></block>
        <block type="arduino_digital_read"></block>
        <block type="arduino_analog_read"></block>
        <block type="arduino_pwm_write"></block>
      </category>
      <category name="Sensors" colour="#059669">
        <block type="arduino_dht"></block>
        <block type="arduino_ultrasonic"></block>
      </category>
      <category name="Actuators & Displays" colour="#d97706">
        <block type="arduino_servo"></block>
        <block type="arduino_oled_print">
          <value name="TEXT">
            <block type="text_literal"></block>
          </value>
        </block>
        <block type="arduino_buzzer"></block>
      </category>
      <category name="Logic" colour="#7c3aed">
        <block type="controls_if"></block>
        <block type="logic_compare"></block>
        <block type="logic_operation"></block>
        <block type="logic_boolean"></block>
      </category>
      <category name="Loops" colour="#c026d3">
        <block type="controls_repeat_ext">
          <value name="TIMES">
            <block type="math_number"><field name="NUM">10</field></block>
          </value>
        </block>
        <block type="controls_whileUntil"></block>
      </category>
      <category name="Math" colour="#2563eb">
        <block type="math_number"></block>
        <block type="math_arithmetic"></block>
      </category>
      <category name="Text" colour="#0d9488">
        <block type="text_literal"></block>
      </category>
    </xml>
  `;

  var blocklyDiv = document.getElementById('blocklyDiv');
  if (!blocklyDiv) return;

  var isLight = (localStorage.getItem('sl-thm') === 'light');
  var injectOptions = {
    toolbox: toolboxXml,
    collapse: true,
    comments: true,
    disable: true,
    maxBlocks: Infinity,
    trashcan: true,
    horizontalLayout: false,
    toolboxPosition: 'start',
    css: true,
    media: 'https://cdnjs.cloudflare.com/ajax/libs/blockly/10.4.3/media/',
    sound: true,
    oneBasedIndex: true,
    grid: {
      spacing: 20,
      length: 3,
      colour: isLight ? 'rgba(99, 102, 241, 0.12)' : 'rgba(99, 102, 241, 0.2)',
      snap: true
    },
    zoom: {
      controls: true,
      wheel: true,
      startScale: 1.0,
      maxScale: 3,
      minScale: 0.3,
      scaleSpeed: 1.2
    }
  };

  if (isLight && codeblocksLightTheme) {
    injectOptions.theme = codeblocksLightTheme;
  } else if (codeblocksDarkTheme) {
    injectOptions.theme = codeblocksDarkTheme;
  }

  blocklyWorkspace = Blockly.inject(blocklyDiv, injectOptions);

  // Default Starter Blocks
  var rootBlock = blocklyWorkspace.newBlock('arduino_program');
  rootBlock.initSvg();
  rootBlock.render();

  var setupDelay = blocklyWorkspace.newBlock('arduino_serial_print');
  setupDelay.initSvg();
  setupDelay.render();
  
  var textBlock = blocklyWorkspace.newBlock('text_literal');
  textBlock.initSvg();
  textBlock.setFieldValue('System initialized with CodeBlocks!', 'TEXT');
  textBlock.render();
  setupDelay.getInput('TEXT').connection.connect(textBlock.outputConnection);
  
  rootBlock.getInput('SETUP').connection.connect(setupDelay.previousConnection);

  var digitalWriteHigh = blocklyWorkspace.newBlock('arduino_digital_write');
  digitalWriteHigh.initSvg();
  digitalWriteHigh.render();

  var delayHigh = blocklyWorkspace.newBlock('arduino_delay');
  delayHigh.initSvg();
  delayHigh.render();

  var digitalWriteLow = blocklyWorkspace.newBlock('arduino_digital_write');
  digitalWriteLow.setFieldValue('LOW', 'STAT');
  digitalWriteLow.initSvg();
  digitalWriteLow.render();

  var delayLow = blocklyWorkspace.newBlock('arduino_delay');
  delayLow.initSvg();
  delayLow.render();

  digitalWriteHigh.nextConnection.connect(delayHigh.previousConnection);
  delayHigh.nextConnection.connect(digitalWriteLow.previousConnection);
  digitalWriteLow.nextConnection.connect(delayLow.previousConnection);

  rootBlock.getInput('LOOP').connection.connect(digitalWriteHigh.previousConnection);
}

// Toggle Theme between Dark Mode & Light Mode in CodeBlocks IDE
function toggleBlocksTheme() {
  var isLight = document.body.classList.toggle('light-theme');
  localStorage.setItem('sl-thm', isLight ? 'light' : 'dark');
  var themeIcon = document.getElementById('themeIcon');
  if (themeIcon) themeIcon.className = isLight ? 'fas fa-moon' : 'fas fa-sun';

  if (blocklyWorkspace) {
    if (isLight && codeblocksLightTheme) {
      blocklyWorkspace.setTheme(codeblocksLightTheme);
    } else if (codeblocksDarkTheme) {
      blocklyWorkspace.setTheme(codeblocksDarkTheme);
    }
  }
}

// Code Generator: Converts Blockly Blocks into compilable Arduino C++
function generateArduinoCppFromBlocks() {
  if (!blocklyWorkspace) return "// Initialize block workspace\n";

  var setupCode = "";
  var loopCode = "";
  var includes = new Set();
  var globalVars = new Set();

  function processBlock(block) {
    if (!block) return "";
    var code = "";
    var type = block.type;

    if (type === 'arduino_delay') {
      var ms = block.getFieldValue('MS');
      code += `  delay(${ms});\n`;
    } else if (type === 'arduino_serial_print') {
      var valBlock = block.getInputTargetBlock('TEXT');
      var valStr = valBlock ? processValueBlock(valBlock) : '"Hello"';
      code += `  Serial.println(${valStr});\n`;
    } else if (type === 'arduino_digital_write') {
      var pin = block.getFieldValue('PIN');
      var stat = block.getFieldValue('STAT');
      setupCode += `  pinMode(${pin}, OUTPUT);\n`;
      code += `  digitalWrite(${pin}, ${stat});\n`;
    } else if (type === 'arduino_pwm_write') {
      var pin = block.getFieldValue('PIN');
      var val = block.getFieldValue('VAL');
      setupCode += `  pinMode(${pin}, OUTPUT);\n`;
      code += `  analogWrite(${pin}, ${val});\n`;
    } else if (type === 'arduino_servo') {
      var pin = block.getFieldValue('PIN');
      var angle = block.getFieldValue('ANGLE');
      includes.add('#include <ESP32Servo.h>');
      globalVars.add(`Servo servo_${pin};`);
      setupCode += `  servo_${pin}.attach(${pin});\n`;
      code += `  servo_${pin}.write(${angle});\n`;
    } else if (type === 'arduino_oled_print') {
      var valBlock = block.getInputTargetBlock('TEXT');
      var valStr = valBlock ? processValueBlock(valBlock) : '"OLED Test"';
      includes.add('#include <Wire.h>');
      includes.add('#include <Adafruit_SSD1306.h>');
      globalVars.add('Adafruit_SSD1306 display(128, 64, &Wire, -1);');
      setupCode += `  display.begin(SSD1306_SWITCHCAPVCC, 0x3C);\n  display.clearDisplay();\n`;
      code += `  display.println(${valStr});\n  display.display();\n`;
    } else if (type === 'arduino_buzzer') {
      var pin = block.getFieldValue('PIN');
      var ms = block.getFieldValue('MS');
      setupCode += `  pinMode(${pin}, OUTPUT);\n`;
      code += `  digitalWrite(${pin}, HIGH);\n  delay(${ms});\n  digitalWrite(${pin}, LOW);\n`;
    }

    var next = block.getNextBlock();
    if (next) {
      code += processBlock(next);
    }
    return code;
  }

  function processValueBlock(block) {
    if (!block) return '""';
    if (block.type === 'text_literal') {
      return `"${block.getFieldValue('TEXT')}"`;
    }
    if (block.type === 'math_number') {
      return block.getFieldValue('NUM');
    }
    if (block.type === 'arduino_digital_read') {
      var pin = block.getFieldValue('PIN');
      setupCode += `  pinMode(${pin}, INPUT);\n`;
      return `digitalRead(${pin})`;
    }
    if (block.type === 'arduino_analog_read') {
      var pin = block.getFieldValue('PIN');
      return `analogRead(${pin})`;
    }
    if (block.type === 'arduino_dht') {
      var pin = block.getFieldValue('PIN');
      var type = block.getFieldValue('TYPE');
      includes.add('#include <DHT.h>');
      globalVars.add(`DHT dht_${pin}(${pin}, DHT22);`);
      setupCode += `  dht_${pin}.begin();\n`;
      return type === 'TEMP' ? `dht_${pin}.readTemperature()` : `dht_${pin}.readHumidity()`;
    }
    return '""';
  }

  var rootBlocks = blocklyWorkspace.getTopBlocks(true);
  rootBlocks.forEach(function(b) {
    if (b.type === 'arduino_program') {
      var setupTarget = b.getInputTargetBlock('SETUP');
      if (setupTarget) setupCode += processBlock(setupTarget);

      var loopTarget = b.getInputTargetBlock('LOOP');
      if (loopTarget) loopCode += processBlock(loopTarget);
    }
  });

  var result = "/*\n  Generated Arduino C++ Code from Visual CodeBlocks\n  Technosankalp Solutions — CodeBlocks IDE\n*/\n\n";

  includes.forEach(inc => result += inc + "\n");
  if (includes.size > 0) result += "\n";

  globalVars.forEach(gv => result += gv + "\n");
  if (globalVars.size > 0) result += "\n";

  result += "void setup() {\n";
  result += "  Serial.begin(115200);\n";
  result += "  Serial.println(\"[SYSTEM] Sketch Initialized from Visual CodeBlocks.\");\n";
  if (setupCode) result += setupCode;
  result += "}\n\n";

  result += "void loop() {\n";
  if (loopCode) {
    result += loopCode;
  } else {
    result += "  delay(1000);\n";
  }
  result += "}\n";

  return result;
}
